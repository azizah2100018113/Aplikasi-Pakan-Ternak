<?php
include_once("../koneksi.php");
include_once("../layout.php");
?>


<div class="container isi-dashboard">
    <h2 style="color : white; font-size: 30px; font-weight: bold;">Selamat datang di Toko Pakan Kami</h2>
    <p style="color : white;">Kami menyediakan berbagai jenis pakan berkualitas untuk hewan ternak dan
        peliharaan
        Anda. Dengan beragam
        kategori dan produk yang kami tawarkan, kami siap melayani kebutuhan pakan Anda.Di sini, Anda dapat
        menemukan produk-produk pakan terbaru kami yang
        berkualitas
        tinggi. Silakan jelajahi
        kategori-kategori pakan kami untuk menemukan yang Anda butuhkan.Kami memiliki tim yang berpengalaman dan
        siap membantu Anda dalam memilih
        pakan yang
        sesuai dengan kebutuhan
        hewan Anda. Jangan ragu untuk menghubungi kami jika Anda memiliki pertanyaan.</p>
</div>


<?php
include_once("../end_layout.php");
?>